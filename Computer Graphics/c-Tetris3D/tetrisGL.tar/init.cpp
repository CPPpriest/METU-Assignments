#include "tetris.h"

void renderText(const std::string &text, GLfloat x, GLfloat y, GLfloat scale, glm::vec3 color)
{
    glUseProgram(gProgram[2]);
    glUniform3f(glGetUniformLocation(gProgram[2], "textColor"), color.x, color.y, color.z);
    glActiveTexture(GL_TEXTURE0);

    for (auto c = text.begin(); c != text.end(); c++) {
        Character ch = Characters[*c];
        GLfloat xpos = x + ch.Bearing.x * scale;
        GLfloat ypos = y - (ch.Size.y - ch.Bearing.y) * scale;

        GLfloat w = ch.Size.x * scale;
        GLfloat h = ch.Size.y * scale;

        GLfloat vertices[6][4] = {
            { xpos,     ypos + h,   0.0f, 0.0f },            
            { xpos,     ypos,       0.0f, 1.0f },
            { xpos + w, ypos,       1.0f, 1.0f },

            { xpos,     ypos + h,   0.0f, 0.0f },
            { xpos + w, ypos,       1.0f, 1.0f },
            { xpos + w, ypos + h,   1.0f, 0.0f }           
        };

        glBindTexture(GL_TEXTURE_2D, ch.TextureID);
        glBindBuffer(GL_ARRAY_BUFFER, gTextVBO);
        glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);

        glDrawArrays(GL_TRIANGLES, 0, 6);
        x += (ch.Advance >> 6) * scale;
    }
    glBindTexture(GL_TEXTURE_2D, 0);
}


void initFonts(int windowWidth, int windowHeight)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glm::mat4 projection = glm::ortho(
        0.0f, static_cast<GLfloat>(windowWidth),
        0.0f, static_cast<GLfloat>(windowHeight)
    );

    glUseProgram(gProgram[2]);
    glUniformMatrix4fv(
        glGetUniformLocation(gProgram[2], "projection"),
        1, GL_FALSE, glm::value_ptr(projection)
    );

    // FreeType
    FT_Library ft;
    if (FT_Init_FreeType(&ft)) {
        std::cout << "ERROR::FREETYPE: Could not init FreeType Library\n";
    }

    // Change font path to a valid TTF on your system
    FT_Face face;
    if (FT_New_Face(
            ft,
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            0, &face))
    {
        std::cout << "ERROR::FREETYPE: Failed to load font\n";
    }

    FT_Set_Pixel_Sizes(face, 0, 48);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    for (GLubyte c = 0; c < 128; c++) {
        if (FT_Load_Char(face, c, FT_LOAD_RENDER)) {
            std::cout << "ERROR::FREETYTPE: Failed to load Glyph\n";
            continue;
        }
        GLuint texture;
        glGenTextures(1, &texture);
        glBindTexture(GL_TEXTURE_2D, texture);
        glTexImage2D(
            GL_TEXTURE_2D, 0, GL_RED,
            face->glyph->bitmap.width,
            face->glyph->bitmap.rows, 0,
            GL_RED, GL_UNSIGNED_BYTE,
            face->glyph->bitmap.buffer
        );
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        Character character = {
            texture,
            glm::ivec2(face->glyph->bitmap.width, face->glyph->bitmap.rows),
            glm::ivec2(face->glyph->bitmap_left, face->glyph->bitmap_top),
            static_cast<GLuint>(face->glyph->advance.x)
        };
        Characters.insert(std::pair<GLchar, Character>(c, character));
    }
    glBindTexture(GL_TEXTURE_2D, 0);

    FT_Done_Face(face);
    FT_Done_FreeType(ft);

    glGenBuffers(1, &gTextVBO);
    glBindBuffer(GL_ARRAY_BUFFER, gTextVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * 6 * 4, NULL, GL_DYNAMIC_DRAW);

    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(GLfloat), 0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
}


bool ReadDataFromFile(const std::string &fileName, std::string &data)
{
    std::fstream myfile;
    myfile.open(fileName.c_str(), std::ios::in);

    if (myfile.is_open()) {
        std::string curLine;
        while (std::getline(myfile, curLine)) {
            data += curLine;
            if (!myfile.eof()) {
                data += "\n";
            }
        }
        myfile.close();
    }
    else {
        return false;
    }
    return true;
}


GLuint createVS(const char *shaderName)
{
    std::string shaderSource;
    if (!ReadDataFromFile(shaderName, shaderSource)) {
        std::cout << "Cannot find file name: " << shaderName << std::endl;
        exit(-1);
    }

    GLint length = (GLint)shaderSource.size();
    const GLchar *shader = (const GLchar *)shaderSource.c_str();

    GLuint vs = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vs, 1, &shader, &length);
    glCompileShader(vs);

    char output[1024] = {0};
    glGetShaderInfoLog(vs, 1024, &length, output);
    printf("VS compile log: %s\n", output);

    return vs;
}


GLuint createFS(const char *shaderName)
{
    std::string shaderSource;
    if (!ReadDataFromFile(shaderName, shaderSource)) {
        std::cout << "Cannot find file name: " << shaderName << std::endl;
        exit(-1);
    }

    GLint length = (GLint)shaderSource.size();
    const GLchar *shader = (const GLchar *)shaderSource.c_str();

    GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fs, 1, &shader, &length);
    glCompileShader(fs);

    char output[1024] = {0};
    glGetShaderInfoLog(fs, 1024, &length, output);
    printf("FS compile log: %s\n", output);

    return fs;
}


void initShaders()
{
    gProgram[0] = glCreateProgram();
    gProgram[1] = glCreateProgram();
    gProgram[2] = glCreateProgram();

    GLuint vs1 = createVS("vert.glsl");
    GLuint fs1 = createFS("frag.glsl");

    GLuint vs2 = createVS("vert2.glsl");
    GLuint fs2 = createFS("frag2.glsl");

    GLuint vs3 = createVS("vert_text.glsl");
    GLuint fs3 = createFS("frag_text.glsl");

    glAttachShader(gProgram[0], vs1);
    glAttachShader(gProgram[0], fs1);
    glAttachShader(gProgram[1], vs2);
    glAttachShader(gProgram[1], fs2);
    glAttachShader(gProgram[2], vs3);
    glAttachShader(gProgram[2], fs3);

    for (int i = 0; i < 3; ++i) {
        glLinkProgram(gProgram[i]);
        GLint status;
        glGetProgramiv(gProgram[i], GL_LINK_STATUS, &status);
        if (status != GL_TRUE) {
            std::cout << "Program link failed: " << i << std::endl;
            exit(-1);
        }
    }

    for (int i = 0; i < 2; ++i) {
        modelingMatrixLoc[i]    = glGetUniformLocation(gProgram[i], "modelingMatrix");
        viewingMatrixLoc[i]     = glGetUniformLocation(gProgram[i], "viewingMatrix");
        projectionMatrixLoc[i]  = glGetUniformLocation(gProgram[i], "projectionMatrix");
        eyePosLoc[i]            = glGetUniformLocation(gProgram[i], "eyePos");
        lightPosLoc[i]          = glGetUniformLocation(gProgram[i], "lightPos");
        kdLoc[i]                = glGetUniformLocation(gProgram[i], "kd");

        glUseProgram(gProgram[i]);
        glUniformMatrix4fv(modelingMatrixLoc[i], 1, GL_FALSE, glm::value_ptr(modelingMatrix));
        glUniform3fv(eyePosLoc[i], 1, glm::value_ptr(eyePos));
        glUniform3fv(lightPosLoc[i], 1, glm::value_ptr(lightPos));
        glUniform3fv(kdLoc[i], 1, glm::value_ptr(kdCubes));
    }
}


void initVBO()
{
    GLuint vao;
    glGenVertexArrays(1, &vao);
    assert(vao > 0);
    glBindVertexArray(vao);

    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    assert(glGetError() == GL_NO_ERROR);

    glGenBuffers(1, &gVertexAttribBuffer);
    glGenBuffers(1, &gIndexBuffer);
    assert(gVertexAttribBuffer > 0 && gIndexBuffer > 0);

    glBindBuffer(GL_ARRAY_BUFFER, gVertexAttribBuffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIndexBuffer);

    // Cube indices (triangles)
    GLuint indices[] = {
        0, 1, 2,  3, 0, 2,
        4, 7, 6,  5, 4, 6,
        0, 3, 4,  3, 7, 4,
        2, 1, 5,  6, 2, 5,
        3, 2, 7,  2, 6, 7,
        0, 4, 1,  4, 5, 1
    };

    // Cube indices (lines for edges)
    GLuint indicesLines[] = {
        7, 3, 2, 6,
        4, 5, 1, 0,
        2, 1, 5, 6,
        5, 4, 7, 6,
        0, 1, 2, 3,
        0, 3, 7, 4,
    };

    // Cube positions
    GLfloat vertexPos[] = {
        0, 0, 1, // front-bottom-left
        1, 0, 1, // front-bottom-right
        1, 1, 1, // front-top-right
        0, 1, 1, // front-top-left
        0, 0, 0, // back-bottom-left
        1, 0, 0, // back-bottom-right
        1, 1, 0, // back-top-right
        0, 1, 0, // back-top-left
    };

    // Normals (one normal per vertex)
    GLfloat vertexNor[] = {
         1.0f,  1.0f,  1.0f, 
         0.0f, -1.0f,  0.0f,
         0.0f,  0.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
        -1.0f,  0.0f,  0.0f,
         1.0f,  0.0f,  0.0f,
         0.0f,  0.0f, -1.0f,
         0.0f,  1.0f,  0.0f
    };

    gVertexDataSizeInBytes     = sizeof(vertexPos);
    gNormalDataSizeInBytes     = sizeof(vertexNor);
    gTriangleIndexDataSizeInBytes = sizeof(indices);
    gLineIndexDataSizeInBytes  = sizeof(indicesLines);
    int allIndexSize           = gTriangleIndexDataSizeInBytes + gLineIndexDataSizeInBytes;

    glBufferData(GL_ARRAY_BUFFER, gVertexDataSizeInBytes + gNormalDataSizeInBytes, nullptr, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, gVertexDataSizeInBytes, vertexPos);
    glBufferSubData(GL_ARRAY_BUFFER, gVertexDataSizeInBytes, gNormalDataSizeInBytes, vertexNor);

    glBufferData(GL_ELEMENT_ARRAY_BUFFER, allIndexSize, nullptr, GL_STATIC_DRAW);
    glBufferSubData(GL_ELEMENT_ARRAY_BUFFER, 0, gTriangleIndexDataSizeInBytes, indices);
    glBufferSubData(GL_ELEMENT_ARRAY_BUFFER, gTriangleIndexDataSizeInBytes, gLineIndexDataSizeInBytes, indicesLines);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(gVertexDataSizeInBytes));
}


void init()
{
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);

    glPolygonOffset(0.5f, 0.5f);
    glEnable(GL_POLYGON_OFFSET_FILL);

    initShaders();
    initVBO();
    initFonts(gWidth, gHeight);
}


void reshape(GLFWwindow *window, int w, int h)
{
    w = w < 1 ? 1 : w;
    h = h < 1 ? 1 : h;

    gWidth = w;
    gHeight = h;
    glViewport(0, 0, w, h);

    float fovyRad = (float)(45.0 / 180.0 * M_PI);
    projectionMatrix = glm::perspective(fovyRad, (float)gWidth / (float)gHeight, 1.0f, 100.0f);

    viewingMatrix = glm::lookAt(eyePos, glm::vec3(0, 0, 0), glm::vec3(0, 1, 0));

    for (int i = 0; i < 2; ++i) {
        glUseProgram(gProgram[i]);
        glUniformMatrix4fv(projectionMatrixLoc[i], 1, GL_FALSE, glm::value_ptr(projectionMatrix));
        glUniformMatrix4fv(viewingMatrixLoc[i], 1, GL_FALSE, glm::value_ptr(viewingMatrix));
    }
}
