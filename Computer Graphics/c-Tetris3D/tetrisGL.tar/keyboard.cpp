#include "tetris.h"


void keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{

    if ((key == GLFW_KEY_Q || key == GLFW_KEY_ESCAPE) && action == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, GLFW_TRUE);
    }


    if ((key == GLFW_KEY_A || key == GLFW_KEY_LEFT) && action == GLFW_PRESS)
    {
        double X = theBoard.mainCube.x;
        double Y = theBoard.mainCube.y;
        double Z = theBoard.mainCube.z;


        if (theBoard.boardState == 0 && (theBoard.mainCube.x > -6))
            theBoard.mainCube.x -= 1;
        else if (theBoard.boardState == 1 && theBoard.mainCube.z < -3)
            theBoard.mainCube.z += 1;
        else if (theBoard.boardState == 2 && theBoard.mainCube.x < 0)
            theBoard.mainCube.x += 1;
        else if (theBoard.boardState == 3 && theBoard.mainCube.z > -9)
            theBoard.mainCube.z -= 1;


        if (theBoard.checkCollision())
            theBoard.mainCube.setLocation(X, Y, Z);

    }


    if ((key == GLFW_KEY_D || key == GLFW_KEY_RIGHT) && action == GLFW_PRESS)
    {
        double X = theBoard.mainCube.x;
        double Y = theBoard.mainCube.y;
        double Z = theBoard.mainCube.z;

        if (theBoard.boardState == 0 && (theBoard.mainCube.x < 0))
            theBoard.mainCube.x += 1;
        else if (theBoard.boardState == 1 && theBoard.mainCube.z > -9)
            theBoard.mainCube.z -= 1;
        else if (theBoard.boardState == 2 && theBoard.mainCube.x > -6)
            theBoard.mainCube.x -= 1;
        else if (theBoard.boardState == 3 && theBoard.mainCube.z < -3)
            theBoard.mainCube.z += 1;

        if (theBoard.checkCollision())
            theBoard.mainCube.setLocation(X, Y, Z);

    }


    if ((key == GLFW_KEY_S || key == GLFW_KEY_DOWN) && action == GLFW_PRESS)
    {
        double X = theBoard.mainCube.x;
        double Y = theBoard.mainCube.y;
        double Z = theBoard.mainCube.z;

        theBoard.mainCube.y -= 1;

        if (theBoard.checkCollision())
            theBoard.mainCube.setLocation(X, Y, Z);

    }


    if ((key == GLFW_KEY_W || key == GLFW_KEY_UP) && action == GLFW_PRESS)
    {
        double X = theBoard.mainCube.x;
        double Y = theBoard.mainCube.y;
        double Z = theBoard.mainCube.z;

        theBoard.mainCube.y += 1;

        if (theBoard.checkCollision())
            theBoard.mainCube.setLocation(X, Y, Z);
    }


    if (key == GLFW_KEY_H && action == GLFW_PRESS)
        theBoard.angleTarget += 90;


    if (key == GLFW_KEY_K && action == GLFW_PRESS)
        theBoard.angleTarget -= 90;
}
