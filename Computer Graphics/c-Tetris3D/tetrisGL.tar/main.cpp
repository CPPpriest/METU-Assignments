#include "tetris.h"
#include <cassert>
GLuint gProgram[3];
int gWidth = 600, gHeight = 1000;
GLuint gVertexAttribBuffer, gTextVBO, gIndexBuffer;
GLuint gTex2D;
int gVertexDataSizeInBytes, gNormalDataSizeInBytes;
int gTriangleIndexDataSizeInBytes, gLineIndexDataSizeInBytes;
GLint modelingMatrixLoc[2];
GLint viewingMatrixLoc[2];
GLint projectionMatrixLoc[2];
GLint eyePosLoc[2];
GLint lightPosLoc[2];
GLint kdLoc[2];
glm::mat4 projectionMatrix;
glm::mat4 viewingMatrix;
glm::mat4 modelingMatrix = glm::translate(glm::mat4(1.f), glm::vec3(-0.5f, -0.5f, -0.5f));
glm::vec3 eyePos = glm::vec3(0, 6, 40);
glm::vec3 lightPos = glm::vec3(0, 5, 24);
glm::vec3 kdCubes = glm::vec3(0.86f, 0.11f, 0.31f);
int activeProgramIndex = 0;
std::map<GLchar, Character> Characters;


BOARD theBoard;


int main(int argc, char **argv)
{
    if (!glfwInit())
        exit(-1);

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow *window = glfwCreateWindow(gWidth, gHeight, "tetrisGL", nullptr, nullptr);
    if (!window) {
        glfwTerminate();
        exit(-1);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    if (GLEW_OK != glewInit()) {
        std::cout << "Failed to initialize GLEW" << std::endl;
        return EXIT_FAILURE;
    }

    char rendererInfo[512] = {0};
    strcpy(rendererInfo, (const char *)glGetString(GL_RENDERER));
    strcat(rendererInfo, " - ");
    strcat(rendererInfo, (const char *)glGetString(GL_VERSION));
    glfwSetWindowTitle(window, rendererInfo);

    init();

    glfwSetKeyCallback(window, keyboard);
    glfwSetWindowSizeCallback(window, reshape);

    reshape(window, gWidth, gHeight);

    glfwWindowHint(GLFW_DOUBLEBUFFER, GLFW_TRUE);
    glfwSwapInterval(1);

    theBoard.initBoard();
    mainLoop(window);

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}


void display()
{

    glClearColor(0, 0, 0, 1);
    glClearDepth(1.0f);
    glClearStencil(0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

    if(theBoard.isGameOver){
        renderText("GAME OVER", gWidth / 4 , gHeight/2, 0.9f, glm::vec3(1, 1, 0));
        renderText("score: ", gWidth / 4 + 40 , gHeight/2 - 40, 0.40f, glm::vec3(1, 1, 0));
        renderText(std::to_string(theBoard.score), gWidth / 4 + 130,  gHeight/2 - 40 , 0.40f, glm::vec3(1, 1, 0));
    }
    else{
        theBoard.checkUpdate();
        theBoard.drawBoard();
        renderText(theBoard.textArray[theBoard.boardState], 50 , gHeight - 25, 0.40f, glm::vec3(1, 1, 0));
        renderText("score: ", gWidth - 120 , gHeight - 25, 0.40f, glm::vec3(1, 1, 0));
        renderText(std::to_string(theBoard.score), gWidth - 70 , gHeight - 25, 0.40f, glm::vec3(1, 1, 0));
        assert(glGetError() == GL_NO_ERROR);
    }

}



void mainLoop(GLFWwindow *window)
{

    int counter = 0;
    while (!glfwWindowShouldClose(window)) {
        
        display();

        if(theBoard.angleTarget < 0){
            theBoard.rotateView(3);
            theBoard.angleTarget += 3;
        }

        if(theBoard.angleTarget > 0){
            theBoard.rotateView(-3);
            theBoard.angleTarget -= 3;
        }
        
        if(theBoard.isGameOver){
            //std::cout << "Game Over Finally" << std::endl;
            if(counter > 1000)
                return;
        }

        else{
            if(counter == 20){
                theBoard.mainCube.y -= 1.0;
                counter = 0;
            }
        }
        counter++;

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
}
