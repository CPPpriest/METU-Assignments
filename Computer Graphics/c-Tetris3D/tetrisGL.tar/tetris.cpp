#include "tetris.h"


void CUBE::drawCube(int enumColor, bool isHalfSize) {

    glm::mat4 transformMatrix = glm::translate(glm::mat4(1.f), glm::vec3(x, y, z));

    if (isHalfSize)
        transformMatrix = glm::scale(transformMatrix, glm::vec3(1.0f, 0.5f, 1.0f));

    glm::vec3 kdColor;
    switch (enumColor) {
        case 0:
            kdColor = glm::vec3(0.0f, 0.0f, 0.8f); 
            break;
        case 1:
            kdColor = glm::vec3(0.86f, 0.11f, 0.31f); 
            break;
        case 2:
            kdColor = glm::vec3(0.5f, 0.9f, 0.2f); 
            break;
        default:
            kdColor = glm::vec3(1.0f, 1.0f, 1.0f);
            break;
    }

    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(1.0f, 1.0f); 

    glUseProgram(gProgram[0]); 
    GLint modelMatrixLocation = glGetUniformLocation(gProgram[0], "modelingMatrix");
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix));

    GLint kdLocation = glGetUniformLocation(gProgram[0], "kd");
    glUniform3fv(kdLocation, 1, glm::value_ptr(kdColor));

    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

    glUseProgram(gProgram[1]); 
    modelMatrixLocation = glGetUniformLocation(gProgram[1], "modelingMatrix");
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix));
    glLineWidth(2);
    for (int i = 0; i < 6; ++i) {
        glDrawElements(GL_LINE_LOOP, 4, GL_UNSIGNED_INT, BUFFER_OFFSET(gTriangleIndexDataSizeInBytes + i * 4 * sizeof(GLuint)));
    }
}


void CUBE::setLocation(double x, double y, double z){
    this->x = x;
    this->y = y;
    this->z = z;
}


void MAIN_CUBE::setLocation(double x, double y, double z){
    this->x = x;
    this->y = y;
    this->z = z;
}


void MAIN_CUBE::drawCube(){

    double X=x;
    double Y=y;
    double Z=z;

    CUBE cube;
    for(int i=0; i<3 ; ++i){
        X += 1;
        
        for(int j=0; j<3 ; ++j){
            Y += 1;
            
            for(int k=0; k< 3 ; ++k){
                Z += 1;
                cube.setLocation(X,Y,Z);
                cube.drawCube(2,false);
            }
            Z=z;
        }
        Y=y;
    }
}


void BOARD::insertCube(){

    double X=mainCube.x;
    double Y=mainCube.y;
    double Z=mainCube.z;

    CUBE cube;
    for(int i=0; i<3 ; ++i){
        X += 1;
        
        for(int j=0; j<3 ; ++j){
            Y += 1;
            
            for(int k=0; k< 3 ; ++k){
                Z += 1;
                cube.setLocation(X,Y,Z);
                grid.push_back(cube);
            }
            Z=mainCube.z;
        }
        Y=mainCube.y;
    }

}


void BOARD::drawBoard(){
    
    int blueCubesCount = 0;
    for(auto cb : grid){
        if(blueCubesCount < 81){
            cb.drawCube(0, true);
            blueCubesCount++;
        }
            
        else
            cb.drawCube(1, false);
    }
    mainCube.drawCube();
}


void BOARD::initBoard(){

    isGameOver = false;
    score = 0;
    boardState = 0;
    boardSize = 9;

    boardX = -5;
    boardY = -8;
    boardZ = -8;
    eyePos0 = glm::vec3(0.0f, 6.0f, 40.0f);

    mainCube.setLocation(-3, 8, -6);
    
    angleY = 0;
    angleTarget = 0;
    
    for (int i = 0; i < boardSize; ++i) {
        for (int j = 0; j < boardSize; ++j) {
            grid.push_back( CUBE( boardX + i, boardY, boardZ + j ) );
        }
    }

}


void BOARD::checkUpdate(){
  
    if(checkCollision()){
        insertCube(); 
        if(grid.back().y == 7)
        {
            isGameOver = true;
            return;
        }
        mainCube.setLocation(-3, 8, -6);
    }

    angleY = int(angleY) % 360;

    if(angleY == 0 )
        theBoard.boardState = 0;
    if(angleY == 90 || angleY == -270)
        theBoard.boardState = 1;
    if(angleY == 180 || angleY == -180)
        theBoard.boardState = 2;
    if(angleY == 270 || angleY == -90)
        theBoard.boardState = 3;


    std::vector<int> toBeDeleted;

    for(int i=-7; i < 9; ++i){ 
        int count = 0;
        for(auto cb : grid){
            if(cb.y == i)
                count++;
            if(count == 81)
                toBeDeleted.push_back(i);
        }
        count = 0;
    }    

    for(auto k : toBeDeleted){
        for (auto it = grid.begin(); it != grid.end(); ) {
            if (it->y == k) {
                it = grid.erase(it);
                score += 1;
            } else {
                ++it;
            }
        }
    }
}


bool BOARD::checkCollision()
{
    double baseX = mainCube.x;
    double baseY = mainCube.y;
    double baseZ = mainCube.z;

    for (int i = 0; i < 3; ++i) {
        baseX += 1;
        double tempY = baseY;
        for (int j = 0; j < 3; ++j) {
            tempY += 1;
            double tempZ = baseZ;
            for (int k = 0; k < 3; ++k) {
                tempZ += 1;
                for (auto &cb : grid) {
                    float dx = fabs(cb.x - baseX);
                    float dy = fabs(cb.y - tempY);
                    float dz = fabs(cb.z - tempZ);
                    if (dx < 1 && dy < 2 && dz < 1)
                        return true;
                }
            }
        }
    }
    return false;
}


void BOARD::rotateView(float delta)
{
    angleY += delta;  

    float eyeRad = glm::length(glm::vec3(eyePos0.x, 0.0f, eyePos0.z));
    float newY = eyePos0.y;
    float newX = eyeRad * sin(glm::radians(angleY));
    float newZ = eyeRad * cos(glm::radians(angleY));

    eyePos = glm::vec3(newX, newY, newZ);

    viewingMatrix = glm::lookAt(
        eyePos,
        glm::vec3(0, 0, 0),
        glm::vec3(0, 1, 0)
    );

    float lightRad = glm::length(glm::vec3(lightPos.x, 0.0f, lightPos.z));
    float lnX = lightRad * sin(glm::radians(angleY));
    float lnZ = lightRad * cos(glm::radians(angleY));

    lightPos = glm::vec3(lnX, lightPos.y, lnZ);

    for (int i = 0; i < 2; ++i)
    {
        glUseProgram(gProgram[i]);
        glUniformMatrix4fv(viewingMatrixLoc[i], 1, GL_FALSE, glm::value_ptr(viewingMatrix));
        glUniform3fv(eyePosLoc[i], 1, glm::value_ptr(eyePos));
        glUniform3fv(lightPosLoc[i], 1, glm::value_ptr(lightPos));
    }
}