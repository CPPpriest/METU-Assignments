#pragma once
#ifndef __TETRISGL_HEADER__
#define __TETRISGL_HEADER__


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <map>
#include <math.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <ft2build.h>
#include FT_FREETYPE_H

#define _USE_MATH_DEFINES
#define BUFFER_OFFSET(i) ((char*)NULL + (i))


extern GLuint gProgram[3];
extern int gWidth, gHeight;
extern GLuint gVertexAttribBuffer, gTextVBO, gIndexBuffer;
extern GLuint gTex2D;
extern int gVertexDataSizeInBytes, gNormalDataSizeInBytes;
extern int gTriangleIndexDataSizeInBytes, gLineIndexDataSizeInBytes;

extern GLint modelingMatrixLoc[2];
extern GLint viewingMatrixLoc[2];
extern GLint projectionMatrixLoc[2];
extern GLint eyePosLoc[2];
extern GLint lightPosLoc[2];
extern GLint kdLoc[2];

extern glm::mat4 projectionMatrix;
extern glm::mat4 viewingMatrix;
extern glm::mat4 modelingMatrix;
extern glm::vec3 eyePos;
extern glm::vec3 lightPos;
extern glm::vec3 kdCubes;

extern int activeProgramIndex;

struct Character {
    GLuint TextureID;
    glm::ivec2 Size;
    glm::ivec2 Bearing;
    GLuint Advance;
};


extern std::map<GLchar, Character> Characters;


struct CUBE
{
    double x,y,z;

    CUBE():x(10),y(10),z(10){};
    CUBE(double x, double y, double z):x(x),y(y),z(z){};

    void setLocation(double x, double y, double z);
    void drawCube(int enumColor, bool isHalfSize);
};


struct MAIN_CUBE
{
    double x,y,z;

    void setLocation(double x, double y, double z);

    void drawCube();
};


struct BOARD
{
    bool isGameOver;
    double maxHeight;
    int boardState;
    int score;
    const char* textArray[4] = {"Front","Right","Back","Left"};
    double boardX, boardY, boardZ;
    int boardSize;
    MAIN_CUBE mainCube;
    float angleTarget;
    float angleY;
    glm::vec3 eyePos0; 

    std::vector<CUBE> grid;
    
    void initBoard();
    void drawBoard();
    void insertCube();

    void rotateView(float delta);

    bool checkCollision();

    void checkUpdate(); 

};


extern BOARD theBoard;



bool   ReadDataFromFile(const std::string &fileName, std::string &data);
GLuint createVS(const char *shaderName);
GLuint createFS(const char *shaderName);

void initFonts(int windowWidth, int windowHeight);
void initShaders();
void initVBO();
void init();

void renderText(const std::string &text, GLfloat x, GLfloat y, GLfloat scale, glm::vec3 color);

void display();
void reshape(GLFWwindow *window, int w, int h);
void keyboard(GLFWwindow *window, int key, int scancode, int action, int mods);
void mainLoop(GLFWwindow *window);



#endif